The code inside the files opdracht_*.py is very similar and could have been
moved inside one file. We chose not to do this, to make it easier to check one
of the specific assignments.

The difference between a) and c) is one line: the return statement in class
'FruitFlyMutation' in def 'get_generation' on line 84.
The difference between b) and d) is also this one line.

The difference between a) & c) and b) & d) is bigger, but is only in the class
'BreakpointSolver' in def 'solve' (line 107) and in def 'main' (line 142).